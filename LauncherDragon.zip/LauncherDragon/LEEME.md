# Launcher Dragón (Android)

Launcher con fondo AMOLED y el dragón animado. La interfaz está en
`app/src/main/assets/index.html`; `MainActivity.kt` la muestra en un WebView y
le da la lista de apps instaladas.

## Cómo sacar el APK

### Opción A: GitHub (solo necesitas un navegador)
1. Crea una cuenta en github.com y un repositorio nuevo (privado está bien).
2. En una computadora, abre el repositorio, toca "Add file > Upload files" y
   arrastra TODO el contenido de esta carpeta (incluida la carpeta `.github`).
3. Entra a la pestaña "Actions". El trabajo "Compilar APK" empieza solo y tarda
   unos 5 minutos.
4. Abre la ejecución terminada y baja "launcher-dragon-apk" (viene en un zip con
   `app-debug.apk` dentro).

### Opción B: Android Studio
1. Abre esta carpeta con Android Studio y espera a que sincronice.
2. Menú Build > Build APK(s). El archivo queda en `app/build/outputs/apk/debug/`.

## Instalar en el celular
1. Pasa `app-debug.apk` al teléfono y ábrelo. Permite "instalar apps de esta fuente".
2. Pulsa el botón de inicio. Android pregunta qué launcher usar: elige
   "Launcher Dragón" y "Siempre".
3. Para volver al anterior: Ajustes > Apps > Apps predeterminadas > App de inicio.

## Notas
- Las fuentes (Orbitron, Share Tech Mono, Rajdhani) se cargan de internet la
  primera vez. Sin conexión se ve con fuentes del sistema.
- Clima, música, tareas y botones rápidos son de ejemplo. Las apps, los íconos y
  la hora son reales.
- No se ha podido compilar ni probar en un teléfono todavía.
